<?php
session_start();

if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}

include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMSAAWEB</title>
    <link rel="shortcut icon" href="aisa.png" type="image/x-icon">
    <link rel="stylesheet" href="css/bootstrap.min (9).css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
  
    <style>


  #maincontent{
		width: auto;
		float: none;
	}

	#sidebar{
		width: auto;
		float: none;
	}

  body {
   background-image: url("background.jpg");
   background-repeat: no-repeat;
   background-size:cover
  }

  .geeks {
  width: 286px;
  height: 160px;
  overflow: hidden;
  margin: 0 auto;
  }
    
  .geeks img {
  width: 100%;
  transition: 0.5s all ease-in-out;
  }
    
  .geeks:hover img {
  transform: scale(1.5);

	}

</style>
</head>

  <!-- navbar -->
  <body class="" style="background-color: #fff">
  <br>
  <nav class="navbar navbar-expand-lg fixed-top shadow-lg p-3 mb-5 bg-body-tertiary rounded" style="background-color:gold">
  <div class="container-fluid text-center">
  <a class = "navbar-brand mb-0 h1" href = "aisa.png">
  <img src = "aisa.png" width = "40" height = "40">
  </a>

  <a class="navbar-brand mb-0 h1"><strong>EMSAAWEB</strong></a>
  <ul class="navbar-nav me-auto mb-2 mb-lg-0">
  </ul>

  <div class="navbar-nav">
  <a href="#" class="nav-link"><button type="submit" class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#exampleModal" ><i class="fa fa-plus-square"></i></button></a>
  <a class="nav-link" href="logout.php"><button class="btn btn-dark bi bi-box-arrow-right"></button></a>
    
</div>
</div>
</nav> 
  
    <div class="container mt-5">
    <?php while($post = mysqli_fetch_assoc($query)) { ?>
    <center>
    <br><div class="card shadow mt-3" style="width: 18rem;">
    <div class="geeks">
    <img class="card-img-top" src="gambar/<?= $post['gambar'] ?>" alt="Card image cap">
    </div>
    <div class="card-body">
    </div>
    
        
    <ul class="list-group list-group-flush">
    <li class="list-group-item"><?= $post['caption'] ?></li>
    <li class="list-group-item"><?= $post['lokasi'] ?></li>
    </ul>

    <div class="card-body">
    <a href="hapus.php?no=<?=$post['no'] ?>"><i class="btn btn-outline-dark fa fa-trash fa-fade" style="font-size:24px"></button></i></a>
    <button type="submit" data-bs-toggle="modal" class="btn btn-outline-warning" data-bs-target="#exampleModal<?= $post['no'] ?>"><i class="fa fa-pencil fa-fade" style="font-size:24px"></i>
    </div>
    </div>
    <br>
    </center>
    
 <!-- modal edit> -->
<div class="modal fade" id="exampleModal<?= $post['no'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel">EMSAAWEB</h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>

  <div class="modal-body">
  <form action="proses_edit.php" method="post" enctype="multipart/form-data">
  <input type="hidden" name="no" value="<?= $post['no'] ?>">
    <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
    
        
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" ><br>
        <img src="gambar/<?= $post['gambar'] ?>" width="200" alt=""><br><br>

        <div class="col-auto">
        <label class="form-label" for="">Caption</label>
        </div>
        <input class="form-control" type="text" name="caption"value="<?= $post['caption'] ?>" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" value="<?= $post['lokasi'] ?>" id="" autocomplete="off"><br>

        <button type="submit" class="btn btn-dark" value="Update" name="update">Ubah</button>

  </form>
  </div>
  </div>
  </div>
  </div>

  <?php } ?>
  </div>

    <!-- modal tambah -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel">EMSAAWEB</h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>

  <div class="modal-body">
  <form action="proses_tambah.php" method="post"enctype="multipart/form-data">
  <label for="">Gambar</label>
  <input type="file" name="gambar" class="form-control" id="" required><br>

  <label for="">Caption</label>
  <input type="text" name="caption" class="form-control" id="" autocomplete="off"><br>

  <label for="">Lokasi</label>
  <input type="text" name="lokasi" class="form-control" id="" autocomplete="off"><br>

  <input type="submit" value="Simpan" name="simpan" class="btn btn-outline-dark">

  </form>
  </div>
  </div>
  </div>
</div>

</body>
</html>


