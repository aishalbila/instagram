<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower|Overpass+Mono" rel="stylesheet">
    <title>EMSAAWEB</title>
    <link rel="shortcut icon" href="aisa.png" type="image/x-icon">
    <style>

    * {
    margin: 0px;
    padding: 0px;
    }
  
    body {
    background-image: url("background.jpg");
    background-repeat: no-repeat;
    background-size:cover;
    }
  
    #wrapper {
    width: 500px;
    height: 50%;
    overflow: hidden;
    border: 0px solid #000;
    margin: 50px auto;
    padding: 10px;
    }
  
    .main-content {
    width: 250px;
    height: 40%;
    border-radius: 20px;
    margin: 10px auto;
    background-color: light;
    border: 2px solid #0F0F0F;
    box-shadow: 5px 5px 10px -2px rgba(0,0,0,.5);
    padding: 40px 50px;
    }
  
    .header {
    border: 0px solid #0F0F0F;
    margin-bottom: 5px;
    }
  
    .header img {
    height: 50px;
    width: 175px;
    margin: auto;
    position: center;
    left: 40px;
    }
  
    .input-1,
    .input-2 {
    width: 100%;
    margin-bottom: 5px;
    padding: 8px 12px;
    border: 1px solid #dbdbdb;
    box-sizing: border-box;
    border-radius: 3px;
    }
  
    .overlap-text {
    position: relative;
    }
  
    .overlap-text a {
    position: absolute;
    top: 8px;
    right: 10px;
    color: #003569;
    font-size: 14px;
    text-decoration: none;
    font-family: 'Overpass Mono', monospace;
    letter-spacing: -1px;
    }
  
    .btn {
    width: 100%;
    background-color: #0F0F0F;
    border: 1px solid #0F0F0F;
    padding: 5px 12px;
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    border-radius: 3px;
    }
  
    .sub-content {
    width: 250px;
    height: 40%;
    margin: 10px auto;
    border: 1px solid #e6e6e6;
    padding: 20px 50px;
    background-color: #000;
    }
  
    .s-part {
    text-align: center;
    font-family: 'Overpass Mono', monospace;
    word-spacing: -3px;
    letter-spacing: -2px;
    font-weight: normal;
    }
  
    .s-part a {
    text-decoration: none;
    cursor: pointer;
    color: #3897f0;
    font-family: 'Overpass Mono', monospace;
    word-spacing: -3px;
    letter-spacing: -2px;
    font-weight: normal;
    }
  
    input:focus {
    background-color: rgb(240, 238, 238);
    }

</style>
</head>
<body>

    <div id="wrapper">
    <div class="main-content">
    <div class="header">
      <center><img src="aisa.png" style="width: 50px; height: 50px;"/><br></center>
      <center><h3>Selamat Datang</h3></center><br>
    </div>

    <div class="l-part">
    <form action="proses_login.php" method="post">
    
    <label for="">Username</label>
    <input type="text" name="username" placeholder="" class="input-1" autocomplete="off"><br><br>

    <label for="">Password</label>
    <input type="password" name = "password" placeholder="" class="input-2" autocomplete="off"><br><br>

    <input type="submit" value="Log in" class="btn">
      </form>
      </div>
    </div>
  </div>
</div>
</body>
</html>